# OCR图片识别

API文档：[OCR图片识别](https://napcat.apifox.cn/226658231e0.md)

## 功能描述
识别图片中的文字

## 请求参数
- image_url: 图片URL

## 响应参数
- text: 识别结果
