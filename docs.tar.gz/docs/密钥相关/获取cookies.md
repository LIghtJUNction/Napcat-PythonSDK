# 获取cookies

API文档：[获取cookies](https://napcat.apifox.cn/226657041e0.md)

## 功能描述
获取当前账号的cookies

## 请求参数
无

## 响应参数
- cookies: cookies字符串
