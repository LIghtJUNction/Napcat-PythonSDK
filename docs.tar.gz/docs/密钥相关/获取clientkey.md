# 获取clientkey

API文档：[获取clientkey](https://napcat.apifox.cn/250286915e0.md)

## 功能描述
获取客户端密钥

## 请求参数
无

## 响应参数
- clientkey: 客户端密钥
