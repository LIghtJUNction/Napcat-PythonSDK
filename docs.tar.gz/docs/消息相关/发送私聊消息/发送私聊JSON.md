# 发送私聊JSON

API文档：[发送私聊JSON](https://napcat.apifox.cn/226889555e0.md)

## 功能描述
发送私聊JSON格式消息

## 请求参数
- user_id: 用户ID
- json_content: JSON内容

## 响应参数
- message_id: 消息ID
