# 发送群AI语音

API文档：[发送群AI语音](https://napcat.apifox.cn/229486774e0.md)

## 功能描述
发送群聊AI生成的语音消息

## 请求参数
- group_id: 群号
- text: 语音内容文本

## 响应参数
- message_id: 消息ID
