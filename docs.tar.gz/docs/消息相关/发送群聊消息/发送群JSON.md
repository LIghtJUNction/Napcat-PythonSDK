# 发送群JSON

API文档：[发送群JSON](https://napcat.apifox.cn/226867165e0.md)

## 功能描述
发送群聊JSON格式消息

## 请求参数
- group_id: 群号
- json_content: JSON内容

## 响应参数
- message_id: 消息ID
